﻿//Assaf Hillel and Michael Aztmon 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dotNetWpf_03_5432_4730
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
        #region
        //class Date
        //{
        //    // such as 29/12/2020
        //    int num1;
        //    char t1;
        //    int num2;
        //    char t2;
        //    int num3;
        //}
        //class Time
        //{
        //    // such as 20:57
        //    int num1;
        //    char t1;
        //    int num2;
        //}
        //class PrinterEventArgs
        //{
        //    bool Mistake;
        //    Date _date;
        //    Time _tine;
        //    string Warning;
        //    string Name;
        //}

        #endregion
        #region
        //public class MyPrinter_1
        //{

        //    private event EventHandler PageMissing;
        //    private event EventHandler<PrinterEventArgs> InkEmpty;
        //    string PrinterName;
        //    public double InkCount {
        //        get {

        //        }
        //        set
        //        {

        //        }
        //    }

        //    public double InkCount
        //    {
        //        get
        //        {
        //            return ((double)(int)(inkCountProgressBar.Value * 10)) / 10;
        //        }
        //        set
        //        {
        //            if (value < 0)
        //                inkCountProgressBar.Value = 0;
        //            else
        //                inkCountProgressBar.Value = value;
        //            inkCountProgressBar.ToolTip = InkCount.ToString() + '%';
        //            if (value <= 15 && value >= 10)
        //            {
        //                inkLabel.Foreground = Brushes.Yellow;
        //            }
        //            else if (value <= 10 && value >= 1)
        //            {
        //                inkLabel.Foreground = Brushes.Orange;
        //            }
        //            else if (value > 0 && value < 1)
        //            {
        //                inkLabel.Foreground = Brushes.Red;
        //            }
        //            else if (value <= 0)
        //            {
        //                inkLabel.Foreground = Brushes.Red;
        //                if (ink_empty != null)
        //                    ink_empty(this, new PrinterEventArgs(true, "Your ink is over", PrinterName));
        //            }
        //            if (InkCount > 0 && InkCount <= 15 && ink_empty != null)
        //                ink_empty(this, new PrinterEventArgs(false, "Your ink is only " + InkCount + "%", PrinterName));

        //        }
        //    }
        //    int PageCount;
        //    int MaxInk = 100;
        //    public event EventHandler<PrinterEventArgs> page_missing
        //    {
        //        add
        //        {
        //            PageMissing += value;
        //        }
        //        remove
        //        {
        //            PageMissing -= value;
        //        }
        //    }
        //    public event EventHandler<PrinterEventArgs> ink_empty
        //    {
        //        add
        //        {
        //            InkEmpty += value;
        //        }
        //        remove
        //        {
        //            InkEmpty -= value;
        //        }
        //    }

        //    public void DoInkOver()
        //    {

        //        for (int i = 0; i < 80; i++)
        //        {
        //            InkCount++;
        //        }
        //        InkEmpty();

        //    }

        //    public void DoPageOver()
        //    {
        //        // do if page over.
        //        Console.WriteLine("error the page ran out");



        //    }
        //    public void printPage()
        //    {
        //        InkCount -= 5;
        //        PageCount--;
        //    }
        //    int counter = 0;
        //    double Min_ADD_INK = 10.0;
        //    double Max_Print_INK = 100.0;
        //    int MaxPages = 400;
        //    int Min_ADD_PAGES = 10;
        //    int MAX_ADD_PAGES = 100;
        //}
        //public delegate void EventHandler(object sender, EventArgs e);

        #endregion



        public partial class PrinterUserControl : UserControl
        {
            private EventHandler<PrinterEventArgs> page_missing;
            private EventHandler<PrinterEventArgs> ink_empty;
            private static Random rand;
            private static uint i = 0;
            public const double MAX_INK = 100;
            public const double MIN_ADD_INK = 17;
            public const double MAX_ADD_INK = 93;
            public const int MAX_PAGES = 400;
            public const int MIN_ADD_PAGES = 51;
            public const int MAX_ADD_PAGES = 391;

            public event EventHandler<PrinterEventArgs> PageMissing
            {
                add
                {
                    page_missing += value;
                }
                remove
                {
                    page_missing -= value;
                }
            }
            public event EventHandler<PrinterEventArgs> InkEmpty
            {
                add
                {
                    ink_empty += value;
                }
                remove
                {
                    ink_empty -= value;
                }
            }
            public string PrinterName
            {
                get
                {
                    return printerNameLable.Content as string;
                }
                set
                {
                    printerNameLable.Content = value;
                }
            }
            public double InkCount
            {
                get
                {
                    return ((double)(int)(inkCountProgressBar.Value * 10)) / 10;
                }
                set
                {
                    if (value < 0)
                        inkCountProgressBar.Value = 0;
                    else
                        inkCountProgressBar.Value = value;
                    inkCountProgressBar.ToolTip = InkCount.ToString() + '%';
                    if (value <= 15 && value >= 10)
                    {
                        inkLabel.Foreground = Brushes.Yellow;
                    }
                    else if (value <= 10 && value >= 1)
                    {
                        inkLabel.Foreground = Brushes.Orange;
                    }
                    else if (value > 0 && value < 1)
                    {
                        inkLabel.Foreground = Brushes.Red;
                    }
                    else if (value <= 0)
                    {
                        inkLabel.Foreground = Brushes.Red;
                        if (ink_empty != null)
                            ink_empty(this, new PrinterEventArgs(true, "Your ink is over", PrinterName));
                    }
                    if (InkCount > 0 && InkCount <= 15 && ink_empty != null)
                        ink_empty(this, new PrinterEventArgs(false, "Your ink is only " + InkCount + "%", PrinterName));

                }
            }
            public int PageCount
            {
                get
                {
                    return (int)pageCountSlider.Value;
                }
                set
                {
                    if (value < 0)
                    {
                        pageCountSlider.Value = 0;
                        pageLabel.Foreground = Brushes.Red; ;
                        if (page_missing != null)
                            page_missing(this, new PrinterEventArgs(true, ("Missing " + ((-1) * value) + " pages"), PrinterName));
                    }
                    else
                        pageCountSlider.Value = value;
                }
            }

            public PrinterUserControl()
            {
                i++;
                InitializeComponent();
                inkCountProgressBar.Maximum = MAX_INK;
                inkCountProgressBar.ToolTip = new ToolTip();
                inkCountProgressBar.ToolTip = InkCount.ToString() + '%';

                pageCountSlider.Maximum = MAX_PAGES;
                pageCountSlider.ToolTip = new ToolTip();
                pageCountSlider.ToolTip = PageCount;

                PrinterName = "Printer " + i;
                rand = new Random();
            }

            private void PrinterNameLabel_MouseLeave(object sender, MouseEventArgs e)
            {
                printerNameLabel.FontSize = 16;
            }
            private void PrinterNameLabel_MouseEnter(object sender, MouseEventArgs e)
            {
                printerNameLabel.FontSize = 40;
            }

            private double doublerand(double MIN = 0, double MAX = 0)
            {
                return rand.Next((int)MIN, (int)MAX) + ((double)rand.Next(99999999) / 100000000);
            }

            public void print()
            {
                InkCount -= doublerand(0, MAX_INK / 15);
                PageCount -= rand.Next(MAX_PAGES / 10);

            }
             
            //
            public void add_ink()
            {
                inkLabel.Foreground = Brushes.Black;
                InkCount += doublerand(MIN_ADD_INK, MAX_ADD_INK - inkCountProgressBar.Value);
            }
            
            //
            public void add_pages()
            {
                pageLabel.Foreground = Brushes.Black;
                PageCount += rand.Next(MIN_ADD_PAGES, MAX_ADD_PAGES - PageCount);
            }

            private void pageCountSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                pageCountSlider.ToolTip = PageCount;
                if (pageCountSlider.Value == 0)
                    pageCountSlider.Foreground = Brushes.Red;
                else
                    pageCountSlider.Foreground = Brushes.Black;
            }
        }
        public class PrinterEventArgs : EventArgs
        {
            private bool iscritical;
            private DateTime datetime_of_the_error;
            private string Error_warrning_Message;
            private string printer_name;

            public bool iscritic
            {
                get
                {
                    return iscritical;
                }
            }
            public DateTime when
            {
                get
                {
                    return datetime_of_the_error;
                }
            }
            public string Message
            {
                get
                {
                    return Error_warrning_Message;
                }
            }
            public string NAME
            {
                get
                {
                    return printer_name;
                }
            }

            public PrinterEventArgs(bool iscriti, string ErrorWarrningMessage, string NAME)
            {
                datetime_of_the_error = DateTime.Now;
                iscritical = iscriti;
                Error_warrning_Message = ErrorWarrningMessage;
                printer_name = NAME;
            }

        }

    }
} 