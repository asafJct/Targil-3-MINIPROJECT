﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dotNetWpf_03_5432_4730
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UserControl1_Loaded(object sender, RoutedEventArgs e)
        {
             public partial class MainWindow : Window
        {
            PrinterUserControl CourentPrinter;
            Queue<PrinterUserControl> queue;

            public MainWindow()
            {
                InitializeComponent();
                queue = new Queue<PrinterUserControl>();
                foreach (PrinterUserControl item in printerGrid.Children.OfType<PrinterUserControl>())
                {
                    item.PageMissing += page_error_handler;
                    item.InkEmpty += ink_error_handler;
                    queue.Enqueue(item);
                }
                CourentPrinter = queue.Dequeue();
            }


            private void page_error_handler(object sender, PrinterEventArgs e)
            {
                MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Pages Missing!!!", MessageBoxButton.OK, MessageBoxImage.Error);
                if (e.iscritic && sender == CourentPrinter)
                {
                    queue.Enqueue(CourentPrinter);
                    CourentPrinter = queue.Dequeue();
                }
                (sender as PrinterUserControl).add_pages();
            }
            private void ink_error_handler(object sender, PrinterEventArgs e)
            {
                if (e.iscritic)
                {
                    MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Ink Missing!!!", MessageBoxButton.OK, MessageBoxImage.Error);
                    if (sender == CourentPrinter)
                    {
                        queue.Enqueue(CourentPrinter);
                        CourentPrinter = queue.Dequeue();
                    }
                    (sender as PrinterUserControl).add_ink();
                }
                else
                    MessageBox.Show("At: " + e.when + "\nMessage from printer: " + e.Message, e.NAME + " Ink Missing!!!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            private void printButton_Click(object sender, RoutedEventArgs e)
            {
                CourentPrinter.print();
            }
        }
    }
}
    

